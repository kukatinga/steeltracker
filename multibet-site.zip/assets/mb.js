/* MULTIBET jackpot card: <div data-mb-card="sportpesa_mega"></div> */
(function(){
var API='https://www.namex.co.ke/api/',STK='https://www.namex.co.ke/slips/send_stk.php';
var ALLOW_SAMPLE_FALLBACK=false; /* set false before launch */
var SAMPLE={prize:'KSh 0',fx:[['Sample Home A','Sample Away B','Sat 15:00'],['Sample Home C','Sample Away D','Sat 17:30'],['Sample Home E','Sample Away F','Sun 16:00'],['Sample Home G','Sample Away H','Sun 18:30']],n:17};
var NAMES={sportpesa_mega:'SportPesa Mega Jackpot',sportpesa_midweek:'SportPesa Midweek Jackpot',betika:'Betika Midweek Jackpot'};
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
function jget(u){var k='mb:'+u,c;try{c=JSON.parse(sessionStorage.getItem(k)||'null');if(c&&Date.now()-c.t<60000)return Promise.resolve(c.d)}catch(e){}
 return fetch(u).then(function(r){return r.json()}).then(function(d){try{sessionStorage.setItem(k,JSON.stringify({t:Date.now(),d:d}))}catch(e){}return d})}
function phone(v){var d=String(v).replace(/\D/g,'');if(d.indexOf('254')===0)d=d.slice(3);else if(d.charAt(0)==='0')d=d.slice(1);return /^[17]\d{8}$/.test(d)?'254'+d:null}
function mask(n){return '0'+n.slice(3,6)+' ••• '+n.slice(-3)}
function ev(n,p){try{if(window.gtag)gtag('event',n,p||{})}catch(e){}}
function init(root){
 var type=root.getAttribute('data-mb-card')||'sportpesa_mega',name=NAMES[type]||'Jackpot';
 root.className='mbc';
 root.appendChild(el('h3','','Get the '+(type==='sportpesa_mega'?'Mega + Midweek':name)+' slips'));
 var sub=el('p','mbc-sub','Enter your M-Pesa number below. You\u2019ll get a prompt on your phone. Enter your PIN and both the Mega and Midweek slips arrive by SMS in about 5 seconds.');root.appendChild(sub);
 var pot=el('div','mbc-pot');pot.hidden=true;pot.appendChild(el('span','','Mega prize'));var potv=el('b','','');pot.appendChild(potv);root.appendChild(pot);
 var fx=el('ol','mbc-fx');fx.hidden=true;root.appendChild(fx);var more=el('p','mbc-more');more.hidden=true;root.appendChild(more);
 var tag=null;
 function sample(){if(!ALLOW_SAMPLE_FALLBACK)return;tag=el('span','mbc-sample','SAMPLE DATA');sub.appendChild(tag);
  potv.textContent=SAMPLE.prize;pot.hidden=false;showFx(SAMPLE.fx.map(function(x,i){return{game_number:i+1,home:x[0],away:x[1],kickoff_display:x[2]}}),SAMPLE.n)}
 function showFx(list,total){fx.textContent='';list.slice(0,4).forEach(function(g){var li=el('li');li.appendChild(el('i','',g.game_number));var d=el('div','',g.home+' v '+g.away);d.appendChild(el('small','',g.kickoff_display||''));li.appendChild(d);fx.appendChild(li)});
  fx.hidden=!list.length;if(total>4){more.textContent='+ '+(total-4)+' more games in this week’s slip';more.hidden=false}}
 Promise.all([jget(API+'prize.php?type='+type).catch(function(){return null}),jget(API+'jackpots.php?type='+type).catch(function(){return null})]).then(function(r){
  var p=r[0],j=r[1],ok=false;
  if(p&&p.success&&Number(p.prize_amount)>0){potv.textContent='KES '+Number(p.prize_amount).toLocaleString('en-KE');pot.hidden=false;ok=true}
  if(j&&j.success&&j.fixtures&&j.fixtures.length){showFx(j.fixtures,j.fixtures.length);ok=true}
  else if(j&&j.success){sub.textContent='This week’s fixtures are not out yet. Check back soon.';ok=true}
  if(!ok)sample();
 });
 var f=el('form');f.noValidate=true;
 var price=el('div','mbc-price');price.append(el('b','','KES 99'),el('span','','Mega + Midweek slips'));var lb=el('label','','Your M-Pesa number');lb.setAttribute('for','mbp-'+type);
 var inp=el('input');inp.type='tel';inp.id='mbp-'+type;inp.placeholder='712 345 678';inp.autocomplete='tel';inp.inputMode='tel';
 var hp=el('input','mbc-hp');hp.type='text';hp.name='website';hp.tabIndex=-1;hp.setAttribute('autocomplete','off');hp.setAttribute('aria-hidden','true');
 var b=el('button','','Pay KES 99 via M-Pesa');b.type='submit';
 var msg=el('div','mbc-msg');msg.hidden=true;msg.setAttribute('role','status');msg.setAttribute('aria-live','polite');
 var row=el('div','mbc-row');row.append(el('span','mbc-cc','+254'),inp);f.append(price,lb,row,hp,b);root.append(f,msg);
 function say(t,c){msg.textContent=t;msg.className='mbc-msg '+(c||'');msg.hidden=false}
 var busy=false;
 f.addEventListener('submit',function(e){e.preventDefault();if(busy||hp.value)return;
  var n=phone(inp.value);if(!n){say('Enter a valid Safaricom number, e.g. 712 345 678.','err');inp.focus();return}
  busy=true;b.disabled=true;b.textContent='Sending prompt…';ev('begin_checkout',{currency:'KES',value:99,items:[{item_name:name}]});
  var done=function(){setTimeout(function(){busy=false;b.disabled=false;b.textContent='Pay KES 99 via M-Pesa'},20000)};
  fetch(STK,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({phone:n})}).then(function(r){return r.json().catch(function(){return{success:false,status:r.status}}).then(function(d){d._s=r.status;return d})}).then(function(d){
   if(d&&d.success){say('Check your phone ('+mask(n)+') and enter your M-Pesa PIN. Both slips arrive by SMS once payment goes through.','ok');ev('stk_sent')}
   else if(d&&d._s===429){say('Too many attempts. Please wait a few minutes, or pay by Paybill 553491, account JP, KES 99.','err')}
   else{say((d&&d.message?d.message+' ':'')+'Could not send the prompt. You can pay by Paybill 553491, account JP, KES 99.','err')}
   done()}).catch(function(){say('Network problem. Try again, or pay by Paybill 553491, account JP, KES 99.','err');done()});
 });
 var dt=el('details');root.appendChild(el('p','mbc-fine mbc-l','You\u2019ll receive an M-Pesa prompt. Enter your PIN to complete.'));dt.appendChild(el('summary','','Prefer to pay manually?'));dt.appendChild(el('p','','M-Pesa > Lipa na M-Pesa > Paybill 553491, account JP, amount 99. Both slips follow by SMS.'));root.appendChild(dt);
 root.appendChild(el('p','mbc-fine','18+ only. Analysis, not a guarantee. Bet responsibly.'));
}
function go(){Array.prototype.forEach.call(document.querySelectorAll('[data-mb-card]'),init)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',go);else go();
})();
